export interface Card {
  category: string
  title: string
  description: string
  src: string
  content: string
}

