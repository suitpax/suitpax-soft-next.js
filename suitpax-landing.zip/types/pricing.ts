export interface Feature {
  icon: string
  title: string
  description?: string
  isNew?: boolean
}

export interface PricingPlan {
  name: string
  price: number
  description: string
  features: Feature[]
  cta: string
  badge?: string
  baseFeatures?: string[]
}

export interface PricingToggleProps {
  isAnnual: boolean
  onToggle: () => void
}

export interface PricingCardProps {
  plan: PricingPlan
  isAnnual: boolean
}

