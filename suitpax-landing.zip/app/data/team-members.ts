export const teamMembers = [
  {
    name: "Gen-3 Alpha Turbo",
    designation: "AI Copilot",
    image: "https://your-image-url.com/gen3-alpha-turbo.jpg",
    video:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Gen-3%20Alpha%20Turbo%20950207519,%20Cropped%20-%201000053593,%20M%205-4lUpZaxS6a52OtbCSebNdG67cYBpqc.mp4",
    badge: "AI",
    progress: 95,
  },
  {
    name: "Amara Johnson",
    designation: "Customer Experience Lead",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/copilot_image_1733258601789-ltw4LyAhNSZRPVAjqqf4ZRgJK0gVax.jpeg",
    badge: "USA",
  },
  {
    name: "Carlos Rodriguez",
    designation: "Destination Expert",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/copilot_image_1733258306688-al7HRFAgfd7AqkjrG0Kk6YZLprfWl5.jpeg",
    badge: "Spain",
  },
  {
    name: "David Chen",
    designation: "Business Development Director",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/copilot_image_1733258306688-al7HRFAgfd7AqkjrG0Kk6YZLprfWl5.jpeg",
    badge: "Singapore",
  },
  {
    name: "Emma Thompson",
    designation: "Service Quality Director",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/copilot_image_1733173245502-OXIsY6wMcdic4XaM1MCrVbL04NTKH5.jpeg",
    badge: "Canada",
  },
  {
    name: "Fatima Al-Sayed",
    designation: "Cultural Intelligence Specialist",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/copilot_image_1733258601789-ltw4LyAhNSZRPVAjqqf4ZRgJK0gVax.jpeg",
    badge: "UAE",
  },
  {
    name: "James Wilson",
    designation: "Operations Manager",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/copilot_image_1732826467689-LrUSEdCDpCE6OhjIGS0NfZ9NtqoLLd.jpeg",
    badge: "UK",
  },
  {
    name: "Ken Yamamoto",
    designation: "Product Strategy Lead",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/copilot_image_1733173204242-niYvBeQyP76ZwuZCBVeCJ38udi482Q.jpeg",
    badge: "Japan",
  },
  {
    name: "Klaudia Weber",
    designation: "Compliance Director",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/copilot_image_1733212173672-DsH7UreNSJAZpZH6AndVbpAiG0obcq.jpeg",
    badge: "Germany",
  },
  {
    name: "Liam O'Connor",
    designation: "Sustainability Officer",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/copilot_image_1732826467689-LrUSEdCDpCE6OhjIGS0NfZ9NtqoLLd.jpeg",
    badge: "Ireland",
  },
  {
    name: "Maya Williams",
    designation: "Global Partnerships Manager",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/copilot_image_1732835194595-gfyHcZhyuZqt3KfxPyAX06ma5tJFUs.jpeg",
    badge: "UK",
  },
  {
    name: "Olivia Kim",
    designation: "User Experience Designer",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/copilot_image_1733173245502-OXIsY6wMcdic4XaM1MCrVbL04NTKH5.jpeg",
    badge: "South Korea",
  },
  {
    name: "Raj Patel",
    designation: "Data Analytics Lead",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/copilot_image_1733173204242-niYvBeQyP76ZwuZCBVeCJ38udi482Q.jpeg",
    badge: "India",
  },
  {
    name: "Sarah Chen",
    designation: "Travel Operations Manager",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/copilot_image_1732826490181-4USKUO5y3l6NeDYC3M5Gwz2Lo12PXc.jpeg",
    badge: "Singapore",
  },
  {
    name: "Sofia Anderson",
    designation: "Innovation Strategy Lead",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/copilot_image_1733253368697-aQN7fWSQN1ixVINQBkn3NEZewFtJVX.jpeg",
    badge: "Sweden",
  },
  {
    name: "Yuki Tanaka",
    designation: "Product Development Director",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/copilot_image_1732746827428-bbbHBRl6EugVikvpW6qoyBlP6SWQLm.jpeg",
    badge: "Japan",
  },
]

