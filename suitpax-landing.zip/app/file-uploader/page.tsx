"use client"

import { useState } from "react"
import { ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Progress } from "@/components/ui/progress"
import { toast } from "sonner"
import Image from "next/image"
import { motion } from "framer-motion"
import { BlobStorageManager } from "@/app/data/blob-storage-manager"
import { CloudArrowUpIcon, ExclamationCircleIcon, XMarkIcon } from "@heroicons/react/24/outline"

interface FileWithPreview extends File {
  preview?: string
}

export default function FileUploader() {
  const [files, setFiles] = useState<FileWithPreview[]>([])
  const [uploading, setUploading] = useState(false)
  const [uploadProgress, setUploadProgress] = useState<{ [key: string]: number }>({})
  const [errorMessage, setErrorMessage] = useState<string | null>(null)
  const [uploadedFiles, setUploadedFiles] = useState<string[]>([])

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const newFiles = Array.from(e.target.files).slice(0, 20 - files.length)
      setFiles((prevFiles) => [
        ...prevFiles,
        ...newFiles.map((file) => Object.assign(file, { preview: URL.createObjectURL(file) })),
      ])
    }
  }

  const removeFile = (index: number) => {
    setFiles((prevFiles) => {
      const updatedFiles = [...prevFiles]
      URL.revokeObjectURL(updatedFiles[index].preview || "")
      updatedFiles.splice(index, 1)
      return updatedFiles
    })
  }

  const handleUpload = async () => {
    setErrorMessage(null)
    setUploading(true)
    setUploadProgress({})
    setUploadedFiles([])

    const uploadPromises = files.map(async (file) => {
      const formData = new FormData()
      formData.append("file", file)

      try {
        const response = await fetch("/api/upload", {
          method: "POST",
          body: formData,
        })

        if (!response.ok) {
          const errorData = await response.json()
          throw new Error(errorData.error || `HTTP error! status: ${response.status}`)
        }

        const data = await response.json()
        setUploadProgress((prev) => ({ ...prev, [file.name]: 100 }))
        return data.url
      } catch (error) {
        console.error(`Upload error for ${file.name}:`, error)
        const errorMsg = error instanceof Error ? error.message : "Unknown error occurred"
        setErrorMessage((prev) => (prev ? `${prev}\n${file.name}: ${errorMsg}` : `${file.name}: ${errorMsg}`))
        return null
      }
    })

    const results = await Promise.all(uploadPromises)
    const successfulUploads = results.filter((url): url is string => url !== null)

    setUploading(false)
    setUploadedFiles(successfulUploads)
    setFiles([])

    if (successfulUploads.length > 0) {
      toast.success(`Successfully uploaded ${successfulUploads.length} file(s)`)
    }
    if (errorMessage) {
      toast.error("Some files failed to upload. Check the error messages for details.")
    }
  }

  return (
    <div className="min-h-screen bg-[#000000] bg-gradient-to-b from-gray-900/50 to-black flex flex-col items-center justify-center p-4 pb-8">
      <div className="w-full mx-auto space-y-6" style={{ maxWidth: "800px" }}>
        <motion.div
          className="text-center space-y-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <Image
            src="/suitpax-cloud-logo.svg"
            alt="Suitpax"
            width={170}
            height={170 * 0.8}
            className="mx-auto"
            priority
          />
          <h1 className="text-2xl text-white font-medium tracking-tight">Multiple File Uploader</h1>
        </motion.div>

        <motion.div
          className="bg-white/10 backdrop-blur-md rounded-2xl p-8 space-y-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.5 }}
        >
          <div className="space-y-4">
            <label
              htmlFor="dropzone-file"
              className="flex flex-col items-center justify-center w-full h-32 border-2 border-emerald-300 border-dashed rounded-lg cursor-pointer bg-gray-700/50 hover:bg-gray-600/50 transition-all duration-300"
            >
              <div className="flex flex-col items-center justify-center pt-5 pb-6">
                <CloudArrowUpIcon className="w-10 h-10 mb-3 text-emerald-400" />
                <p className="mb-2 text-sm text-emerald-100">
                  <span className="font-bold">Click to upload</span> or drag and drop
                </p>
                <p className="text-xs text-emerald-300">SVG, PNG, JPG or GIF (MAX. 20 files)</p>
              </div>
              <Input
                id="dropzone-file"
                type="file"
                className="hidden"
                onChange={handleFileChange}
                multiple
                accept="image/*"
              />
            </label>

            {files.length > 0 && (
              <div className="space-y-2">
                <h3 className="text-sm font-semibold text-emerald-100">Selected Files:</h3>
                <div className="max-h-40 overflow-y-auto">
                  {files.map((file, index) => (
                    <div
                      key={index}
                      className="flex items-center justify-between bg-emerald-900/50 p-2 rounded-lg mb-2"
                    >
                      <span className="text-sm text-emerald-100 truncate">{file.name}</span>
                      <Button
                        onClick={() => removeFile(index)}
                        variant="ghost"
                        size="icon"
                        className="text-red-500 hover:bg-red-100"
                      >
                        <XMarkIcon className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <Button
              onClick={handleUpload}
              disabled={files.length === 0 || uploading}
              className="w-full bg-gray-600 hover:bg-gray-700 text-white transition-colors duration-300"
            >
              {uploading ? "Uploading..." : `Upload ${files.length} file${files.length !== 1 ? "s" : ""}`}
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>

            {uploading && (
              <div className="space-y-2">
                <Progress
                  value={Object.values(uploadProgress).reduce((a, b) => a + b, 0) / files.length}
                  className="w-full"
                />
                <p className="text-xs text-emerald-300 text-center">
                  Uploading {Object.keys(uploadProgress).length} of {files.length} files
                </p>
              </div>
            )}

            {errorMessage && (
              <div className="mt-4 p-3 bg-red-900/50 border border-red-500 text-red-100 rounded-lg">
                <ExclamationCircleIcon className="inline mr-2 h-5 w-5" />
                {errorMessage}
              </div>
            )}
          </div>
        </motion.div>

        {uploadedFiles.length > 0 && (
          <motion.div
            className="mt-6 p-4 bg-white/10 backdrop-blur-md rounded-2xl"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.5 }}
          >
            <h2 className="text-lg font-semibold text-emerald-100 mb-4">Uploaded Files:</h2>
            <div className="grid grid-cols-2 gap-4">
              {uploadedFiles.map((url, index) => (
                <div key={index} className="relative">
                  <Image
                    src={url || "/placeholder.svg"}
                    alt={`Uploaded file ${index + 1}`}
                    width={300}
                    height={200}
                    className="rounded-lg shadow-md w-full h-auto object-cover"
                    unoptimized
                  />
                  <div className="absolute bottom-2 sm:bottom-4 left-2 sm:left-4 right-2 sm:right-4 text-xs sm:text-sm text-white/90 bg-black/40 px-3 py-2 rounded-lg backdrop-blur-sm truncate">
                    {url.split("/").pop()}
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        )}

        <motion.div
          className="mt-6 w-full bg-gradient-to-br from-gray-900 to-gray-800 backdrop-blur-md rounded-2xl shadow-lg border border-gray-700"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6, duration: 0.5 }}
        >
          <BlobStorageManager
            onCopy={(url) => {
              navigator.clipboard
                .writeText(url)
                .then(() => {
                  toast.success("URL copiada al portapapeles")
                })
                .catch((err) => {
                  console.error("Error al copiar: ", err)
                  toast.error("No se pudo copiar la URL")
                })
            }}
          />
        </motion.div>
      </div>
    </div>
  )
}

