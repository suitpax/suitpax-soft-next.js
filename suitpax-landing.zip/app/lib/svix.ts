import { Svix } from "svix"

// Initialize Svix client
const svix = new Svix(process.env.SVIX_API_KEY)

// Example function to create an application
export async function createSvixApplication(name: string) {
  try {
    const app = await svix.application.create({
      name: name,
      uid: name.toLowerCase().replace(/\s+/g, "-"),
    })
    return app
  } catch (error) {
    console.error("Error creating Svix application:", error)
    throw error
  }
}

// Example function to create an endpoint
export async function createSvixEndpoint(appId: string, url: string) {
  try {
    const endpoint = await svix.endpoint.create(appId, {
      url: url,
      version: 1,
    })
    return endpoint
  } catch (error) {
    console.error("Error creating Svix endpoint:", error)
    throw error
  }
}

// Example function to send a message
export async function sendSvixMessage(appId: string, eventType: string, payload: any) {
  try {
    const message = await svix.message.create(appId, {
      eventType: eventType,
      payload: payload,
    })
    return message
  } catch (error) {
    console.error("Error sending Svix message:", error)
    throw error
  }
}

