import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "@/app/globals.css"
import { Theme } from "@radix-ui/themes"
import { Nav } from "@/app/components/nav"
import { Footer } from "@/app/components/footer"
import { cn } from "@/app/lib/utils"
import { IntercomProvider } from "@/app/components/ui/intercom-provider"
import { VercelAnalytics } from "@/app/components/analytics"
import { VercelSpeedInsights } from "@/app/components/speed-insights"
import { Header } from "@/app/components/header"
import Link from "next/link"
import type React from "react"

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
})

export const metadata: Metadata = {
  title: "Suitpax",
  description:
    "Suitpax is an AI-powered travel management software for modern travelers and companies. Streamline bookings, VIP services, and more.",
  keywords: [
    "travel management",
    "AI travel solutions",
    "business travel",
    "travel efficiency",
    "travel integration",
    "intelligent travel platform",
    "AI travel",
    "airport solutions",
    "flight search",
    "travel software",
    "vip lounge",
    "airport vip lounge",
    "expense management solutions"
  ],
  authors: [{ name: "Suitpax" }],
  creator: "Suitpax",
  openGraph: {
    type: "website",
    locale: "en_US",
    url: "https://suitpax.com",
    site_name: "Suitpax",
    title: "Suitpax - Where travel meets intelligence",
    description:
      "Revolutionizing travel management with AI-powered solutions. Seamless integration and efficiency for modern travel companies.",
    images: [
      {
        url: "https://www.suitpax.com/og-image.jpg",
        width: 1200,
        height: 630,
        alt: "Suitpax - Where travel meets intelligence",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Suitpax - Where travel meets intelligence",
    description:
      "Revolutionizing travel management with AI-powered solutions. Seamless integration and efficiency for modern travel companies.",
    images: ["https://www.suitpax.com/twitter-image.jpg"],
    creator: "@suitpax",
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  icons: {
    icon: "https://ny10xbvnsvd5lllr.public.blob.vercel-storage.com/SUITPAX-SIGNATURE_20241230_053706_0000-WeL0EADsliCpLpAjHXFDvx1BLHTT8c.ico",
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" className={inter.variable}>
      <head>
        {/* Google tag (gtag.js) */}
        <script async src="https://www.googletagmanager.com/gtag/js?id=G-C77M03G9MN"></script>
        <script
          dangerouslySetInnerHTML={{
            __html: `
              window.dataLayer = window.dataLayer || [];
              function gtag(){dataLayer.push(arguments);}
              gtag('js', new Date());

              gtag('config', 'G-C77M03G9MN');
            `,
          }}
        />

        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: `
{
  "@context": "https://schema.org",
  "@type": "Organization",
  "name": "Suitpax",
  "url": "https://suitpax.com",
  "logo": "https://suitpax.com/suitpax-main-logo.svg",
  "sameAs": [
    "https://www.facebook.com/suitpax",
    "https://twitter.com/suitpax",
    "https://www.linkedin.com/company/suitpax",
    "https://github.com/suitpax",
    "https://www.instagram.com/suitpax"
  ],
  "contactPoint": {
    "@type": "Contact",
    "email": "hello@suitpax.com",
    "contactType": "customer service"
  }
}
            `,
          }}
        />
      </head>
      <body className={cn(inter.className, "flex flex-col min-h-screen overflow-x-hidden")}>
        <IntercomProvider>
          <Theme>
            <Header />
            <Nav>
              <nav>
                <ul>
                  <li>
                    <Link href="/" className="font-medium text-gray-900 dark:text-gray-100">
                      Home
                    </Link>
                  </li>
                  <li>
                    <Link href="/pricing" className="font-medium text-gray-900 dark:text-gray-100">
                      Pricing
                    </Link>
                  </li>
                  <li>
                    <Link href="/careers" className="font-medium text-gray-900 dark:text-gray-100">
                      Careers
                    </Link>
                  </li>
                  <li>
                    <Link href="/manifest" className="font-medium text-gray-900 dark:text-gray-100">
                      Manifest
                    </Link>
                  </li>
                </ul>
              </nav>
            </Nav>
            {children}
            <Footer />
          </Theme>
        </IntercomProvider>
        {process.env.NODE_ENV === "production" && (
          <>
            <VercelAnalytics />
            <VercelSpeedInsights />
          </>
        )}
      </body>
    </html>
  )
}



import './globals.css'