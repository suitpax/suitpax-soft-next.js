"use client"

import { useState, useMemo } from "react"
import { motion } from "framer-motion"
import { PricingToggle } from "@/app/components/pricing-toggle"
import { PricingCard } from "@/app/components/pricing-card"
import { pricingPlans } from "@/app/data/pricing"

const PricingHeader = () => (
  <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-12">
    <h1 className="text-2xl font-medium mb-4 text-emerald-950 tracking-tighter">Travel as you know it is about to change. Forever.
    </h1>
    <p className="text-gray-600 text-sm">Start for free, no credit card required.</p>
  </motion.div>
)

export default function PricingPage() {
  const [isAnnual, setIsAnnual] = useState(false)
  const [activePlanIndex, setActivePlanIndex] = useState(2)

  const currentPlan = useMemo(() => pricingPlans[activePlanIndex], [activePlanIndex])

  const handlePrevPlan = () => {
    setActivePlanIndex((prev) => (prev > 0 ? prev - 1 : pricingPlans.length - 1))
  }

  const handleNextPlan = () => {
    setActivePlanIndex((prev) => (prev < pricingPlans.length - 1 ? prev + 1 : 0))
  }

  const handleToggle = () => {
    setIsAnnual((prev) => !prev)
  }

  return (
    <div className="min-h-screen bg-white py-24">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <PricingHeader />

          <PricingToggle isAnnual={isAnnual} onToggle={handleToggle} />

          <div className="relative">
            <PricingCard
              plan={currentPlan}
              isAnnual={isAnnual}
              onPrevPlan={handlePrevPlan}
              onNextPlan={handleNextPlan}
            />
          </div>
        </div>
      </div>
    </div>
  )
}

