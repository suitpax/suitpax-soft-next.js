"use client"

import React from "react"
import Link from "next/link"
import { motion, AnimatePresence } from "framer-motion"
import Image from "next/image"
import {
  LightBulbIcon,
  BookOpenIcon,
  CodeBracketIcon,
  CurrencyDollarIcon,
  ChevronDownIcon,
  QuestionMarkCircleIcon,
  AcademicCapIcon,
  ChatBubbleLeftEllipsisIcon,
  GlobeAltIcon,
  WrenchIcon,
  MagnifyingGlassIcon,
  DocumentTextIcon,
  CreditCardIcon,
  InboxIcon,
  InformationCircleIcon,
  EnvelopeIcon,
  UserGroupIcon,
} from "@heroicons/react/24/outline"
import { FaTwitter, FaLinkedin, FaGithub, FaInstagram } from "react-icons/fa"
import { useState } from "react"
import { BuildingOffice2Icon } from "@heroicons/react/24/outline"
import { CalendarDaysIcon } from "@heroicons/react/24/outline"
import { Card, CardContent } from "@/components/ui/card" // Import Card component

import { Header } from "@/app/components/header"
import { BarsButton } from "@/app/components/ui/bars-button"

const navItems = [
  {
    name: "Products",
    href: "/products",
    subsections: [
      { name: "Travel Management", badge: "New", icon: GlobeAltIcon },
      { name: "Booking Engine", badge: null, icon: MagnifyingGlassIcon },
      { name: "Expense Tracking", badge: null, icon: DocumentTextIcon },
      { name: "Travel Cards", badge: null, icon: CreditCardIcon },
      { name: "Package+", badge: null, icon: InboxIcon },
      { name: "Airport Access", badge: null, icon: WrenchIcon },
    ],
  },
  {
    name: "Services",
    href: "/services",
    subsections: [
      { name: "Concierge", badge: "24/7", icon: LightBulbIcon },
      { name: "Corporate Travel", badge: null, icon: BuildingOffice2Icon },
      { name: "Event Planning", badge: null, icon: CalendarDaysIcon },
    ],
  },
  {
    name: "Solutions",
    href: "/solutions",
    subsections: [
      { name: "For SMEs", badge: "Popular", icon: UserGroupIcon },
      { name: "For Enterprises", badge: null, icon: BuildingOffice2Icon },
      { name: "For Travel Agencies", badge: null, icon: BuildingOffice2Icon },
    ],
  },
  {
    name: "Resources",
    href: "/resources",
    subsections: [
      { name: "Documentation", badge: "Updated", icon: DocumentTextIcon },
      { name: "Guides", badge: null, icon: BookOpenIcon },
      { name: "Blog", badge: null, icon: DocumentTextIcon },
    ],
  },
  {
    name: "Developers",
    href: "/developers",
    subsections: [
      { name: "API", badge: "v2", icon: CodeBracketIcon },
      { name: "SDKs", badge: null, icon: CodeBracketIcon },
      { name: "Community", badge: "Join", icon: UserGroupIcon },
      { name: "Tutorials", badge: null, icon: DocumentTextIcon },
    ],
  },
  {
    name: "Pricing",
    href: "/pricing",
    subsections: [
      { name: "Plans", badge: "Compare", icon: CurrencyDollarIcon },
      { name: "Enterprise", badge: "Custom", icon: BuildingOffice2Icon },
      { name: "Contact Sales", badge: null, icon: ChatBubbleLeftEllipsisIcon },
    ],
  },
  {
    name: "Company",
    href: "/company",
    subsections: [
      { name: "About", badge: null, icon: InformationCircleIcon },
      { name: "Careers", badge: "We're Hiring!", icon: BuildingOffice2Icon },
      { name: "Contact", badge: null, icon: EnvelopeIcon },
      { name: "Partners", badge: null, icon: UserGroupIcon },
    ],
  },
  {
    name: "Support",
    href: "/support",
    subsections: [
      { name: "Help Center", href: "/help", icon: QuestionMarkCircleIcon },
      { name: "Academy", href: "/academy", icon: AcademicCapIcon },
      { name: "Travel Assistant", href: "/assistant", icon: ChatBubbleLeftEllipsisIcon },
    ],
  },
]

/**
 * Main navigation component
 *
 * @returns {JSX.Element} The rendered Nav component
 */
export function Nav() {
  const [isOpen, setIsOpen] = React.useState(false)
  const [openDropdowns, setOpenDropdowns] = useState<{ [key: string]: boolean }>({})
  //const { user, logout } = useStore()

  const handleMenuToggle = () => {
    setIsOpen(!isOpen)
  }

  const toggleDropdown = (itemName: string) => {
    setOpenDropdowns((prev) => ({ ...prev, [itemName]: !prev[itemName] }))
  }

  React.useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = "hidden"
    } else {
      document.body.style.overflow = "unset"
    }
  }, [isOpen])

  const handleItemClick = (item) => {
    if (item.subsections && item.subsections.length > 0) {
      toggleDropdown(item.name)
    }
  }

  return (
    <>
      <Header onMenuToggle={handleMenuToggle} />
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1.5 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 z-50 bg-black backdrop-filter backdrop-blur-3xl"
          >
            <div className="flex flex-col h-full">
              <div className="flex items-center justify-between px-4 sm:px-6 pt-4 sm:pt-6 pb-2 sm:pb-4">
                <Link href="/" className="flex items-center" onClick={() => setIsOpen(false)}>
                  <Image
                    src="/suitpax-cloud-logo.svg"
                    alt="Suitpax"
                    width={100}
                    height={22}
                    className="h-6 sm:h-6 w-auto"
                  />
                </Link>
                <div className="flex items-center gap-2 sm:gap-3">
                  <Link
                    href="/auth/sign-in"
                    className="px-2 py-1 text-sm sm:text-base font-medium text-black bg-white rounded-md hover:bg-gray-100"
                    onClick={() => setIsOpen(false)}
                  >
                    Log in
                  </Link>
                  <Link
                    href="/auth/sign-up"
                    className="px-2 py-1 text-sm sm:text-base font-medium text-black bg-white rounded-md hover:bg-gray-100"
                    onClick={() => setIsOpen(false)}
                  >
                    Sign up
                  </Link>
                  <BarsButton onClick={() => setIsOpen(false)} isOpen={isOpen} />
                </div>
              </div>
              <div className="flex-1 overflow-y-auto px-4 sm:px-6 py-4 sm:py-6 space-y-6">
                <nav className="space-y-4">
                  {navItems.map((item) => (
                    <div key={item.name} className="relative group">
                      <button
                        onClick={() => handleItemClick(item)}
                        className="flex items-center justify-between w-full font-semibold text-left text-gray-200 hover:text-gray-300 transition-colors py-2 px-3 rounded-md hover:bg-white/5"
                      >
                        {item.name}
                        <ChevronDownIcon
                          className={`h-5 w-5 transition-transform ${
                            openDropdowns[item.name] ? "transform rotate-180" : ""
                          }`}
                        />
                      </button>
                      {openDropdowns[item.name] && (
                        <motion.div
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          exit={{ opacity: 0, x: -20 }}
                          className="mt-2 space-y-2 pl-2 border-l border-gray-700"
                        >
                          {item.subsections.map((subsection) => (
                            <Link
                              key={subsection.name}
                              href={
                                typeof subsection.href === "string"
                                  ? subsection.href
                                  : `${item.href}/${subsection.name.toLowerCase().replace(/\s+/g, "-")}`
                              }
                              className="flex items-center text-sm text-gray-400 hover:text-white transition-colors py-2 px-3 rounded-md hover:bg-white/5 group"
                              onClick={() => setIsOpen(false)}
                            >
                              {subsection.icon && (
                                <span className="p-1.5 mr-2 rounded-md bg-gray-500/20 backdrop-blur-sm">
                                  <subsection.icon className="w-4 h-4" />
                                </span>
                              )}
                              {subsection.name} {/* Subsection name displayed next to the icon */}
                            </Link>
                          ))}
                        </motion.div>
                      )}
                    </div>
                  ))}
                </nav>
                <Card className="mt-6 p-4 bg-white/5 backdrop-blur-md rounded-lg border border-gray-300">
                  <CardContent>
                    <div className="mb-3 text-justify-left">
                      {" "}
                      <span className="px-1.5 py-0.5 bg-emerald-900 text-emerald-300 text-[10px] font-semibold rounded-full">
                        New
                      </span>
                      <h3 className="text-base font-bold text-white mt-1.5">Suitpax v.0.1 is here!</h3>
                      <p className="text-xs text-gray-300 mt-1">Experience the next level of travel softwar.</p>
                    </div>
                    <h4 className="text-xs font-semibold text-white mb-1.5">What's New:</h4>
                    <ul className="text-[11px] text-gray-400 mb-3 list-disc list-inside">
                      <li>Enhanced AI-powered itinerary planning</li>
                      <li>Real-time flight tracking</li>
                      <li>More travel partners</li>
                    </ul>
                    <h4 className="text-xs font-semibold text-white mb-1.5">Let's collaborate</h4>
                    <p className="text-[11px] text-gray-400 mb-3">
                      Contact us to improve the next gen travel software stack:
                      <br />
                      <a
                        href="mailto:hello@suitpax.com"
                        className="font-medium text-emerald-400 hover:underline inline-flex items-center px-3 py-0.5 rounded text-xs font-medium bg-emerald-100 text-emerald-700 mt-1"
                      >
                        hello@suitpax.com
                      </a>
                    </p>
                  </CardContent>
                </Card>
                <div className="mt-auto border-t border-zinc-800">
                  <div className="flex items-center justify-left p-4 space-x-4">
                    <a href="https://twitter.com" target="_blank" rel="noopener noreferrer">
                      <FaTwitter className="text-gray-400 hover:text-white text-lg" />
                    </a>
                    <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer">
                      <FaLinkedin className="text-gray-400 hover:text-white text-lg" />
                    </a>
                    <a href="https://github.com" target="_blank" rel="noopener noreferrer">
                      <FaGithub className="text-gray-400 hover:text-white text-lg" />
                    </a>
                    <a href="https://instagram.com" target="_blank" rel="noopener noreferrer">
                      <FaInstagram className="text-gray-400 hover:text-white text-lg" />
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}

