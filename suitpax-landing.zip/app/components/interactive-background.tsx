// Removed all Lucide icons as they were decorative

