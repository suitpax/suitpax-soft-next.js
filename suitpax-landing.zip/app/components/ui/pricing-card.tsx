"use client"

import { motion } from "framer-motion"
import { ChevronLeftIcon, ChevronRightIcon } from "@heroicons/react/24/outline"
import { Button } from "@/components/ui/button"
import { NumberFlow } from "./number-flow"
import { Card } from "@/components/ui/card"
import * as HeroIcons from "@heroicons/react/24/outline"

export interface PricingPlan {
  name: string
  description: string
  price: number
  cta: string
  badge?: string
  features: {
    title: string
    icon: keyof typeof HeroIcons
    isNew?: boolean
  }[]
}

export interface ExtendedPricingCardProps {
  plan: PricingPlan
  isAnnual: boolean
  onPrevPlan: () => void
  onNextPlan: () => void
}

export function PricingCard({ plan, isAnnual, onPrevPlan, onNextPlan }: ExtendedPricingCardProps) {
  // Calculate price with annual discount if applicable
  const monthlyPrice = isAnnual ? plan.price * 0.8 : plan.price
  const annualPrice = monthlyPrice * 12

  return (
    <Card className="relative bg-[#f8fafc] p-8 rounded-2xl">
      <div className="flex items-start justify-between mb-6">
        <div className="flex items-center gap-2">
          <motion.h3
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-lg font-medium px-3 py-1 bg-gray-100 rounded-full"
          >
            {plan.name}
          </motion.h3>
          {plan.badge && (
            <span className="px-1 py-0.5 bg-emerald-950 text-emerald-300 text-xs font-medium rounded-full">{plan.badge}</span>
          )}
        </div>
      </div>

      <p className="text-gray-600 text-sm mb-6">{plan.description}</p>

      <div className="flex items-center justify-between mb-8">
        <div className="flex items-baseline gap-1">
          <NumberFlow value={monthlyPrice} prefix="$" className="text-3xl font-bold" />
          <span className="text-gray-500 text-sm">per month</span>
        </div>
        {isAnnual && (
          <div className="text-xs text-gray-500">
            <span className="line-through">${plan.price}</span> ${monthlyPrice.toFixed(2)} billed monthly
          </div>
        )}
      </div>

      {isAnnual && (
        <div className="mb-8 text-xs text-gray-600">${annualPrice.toFixed(2)} billed annually (Save 20%)</div>
      )}

      <div className="flex items-center gap-2 mb-6">
        <button
          onClick={onPrevPlan}
          className="w-8 h-8 flex items-center justify-center rounded-full bg-gray-100 hover:bg-gray-200 transition-colors"
        >
          <ChevronLeftIcon className="w-4 h-4 text-gray-600" />
        </button>
        <Button className="flex-1 bg-emerald-950 hover:bg-emerald-900 text-white py-2 px-4 rounded-lg text-sm font-medium">
          {plan.cta}
        </Button>
        <button
          onClick={onNextPlan}
          className="w-8 h-8 flex items-center justify-center rounded-full bg-gray-100 hover:bg-gray-200 transition-colors"
        >
          <ChevronRightIcon className="w-4 h-4 text-gray-600" />
        </button>
      </div>

      <div className="space-y-4">
        <h4 className="font-medium text-gray-900 text-sm">Everything in Pro, plus:</h4>
        {plan.features.map((feature, index) => {
          const Icon = HeroIcons[feature.icon as keyof typeof HeroIcons]
          return (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
              className="flex items-center gap-2"
            >
              <Icon className="w-4 h-4 text-gray-400" />
              <span className="text-gray-600 text-xs">{feature.title}</span>
              {feature.isNew && (
                <span className="px-1 py-0.5 bg-black text-white text-[10px] font-medium rounded-full">NEW</span>
              )}
            </motion.div>
          )
        })}
      </div>
    </Card>
  )
}

