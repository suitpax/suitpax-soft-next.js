"use client"

import { motion, useAnimationControls } from "framer-motion"
import {
  Clock,
  Plane,
  Car,
  BedDouble,
  Calendar,
  Bell,
  Loader2,
  Briefcase,
  CreditCard,
  Menu,
  Search,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import Image from "next/image"
import { useTheme } from "next-themes"
import { AnimatedCounter } from "./animated-counter"
import { ChartComponent } from "./chart-component"
import { MenuDashboard } from "./menu-dashboard"
import { HorizontalPriceChart } from "./horizontal-price-chart"
import { useState, useEffect } from "react"

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
}

const itemVariants = {
  hidden: { y: 20, opacity: 0 },
  visible: {
    y: 0,
    opacity: 1,
    transition: {
      type: "spring",
      stiffness: 100,
    },
  },
}

const FlightBadge = ({ from, to, isDark }) => (
  <motion.div
    className={`relative inline-flex items-center space-x-1 px-1.5 py-0.5 rounded-md text-[8px] ${
      isDark ? "bg-background border border-input text-gray-400" : "bg-background border border-input text-gray-500"
    }`}
    whileHover={{ scale: 1.05 }}
  >
    <motion.span
      className="absolute inset-0 rounded-md"
      animate={{
        boxShadow: [
          `0 0 0 1px ${isDark ? "rgba(255,255,255,0.1)" : "rgba(0,0,0,0.1)"}`,
          `0 0 0 2px ${isDark ? "rgba(255,255,255,0.1)" : "rgba(0,0,0,0.1)"}`,
          `0 0 0 1px ${isDark ? "rgba(255,255,255,0.1)" : "rgba(0,0,0,0.1)"}`,
        ],
      }}
      transition={{ duration: 1.5, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
    />
    <span className="relative flex h-1 w-1 mr-1">
      <span
        className={`animate-ping absolute inline-flex h-full w-full rounded-full ${isDark ? "bg-green-400" : "bg-green-500"} opacity-75`}
      ></span>
      <span className={`relative inline-flex rounded-full h-1 w-1 ${isDark ? "bg-green-500" : "bg-green-600"}`}></span>
    </span>
    <span className="w-10 text-right">{from}</span>
    <Plane className="w-1.5 h-1.5 mx-0.5 transform rotate-90" />
    <span className="w-10 text-left">{to}</span>
  </motion.div>
)

const priceChartData = [
  { label: "Flights", price: 2500, color: "#3498db" },
  { label: "Accommodation", price: 1800, color: "#2ecc71" },
  { label: "Transportation", price: 500, color: "#e74c3c" },
  { label: "Meals & Entertainment", price: 700, color: "#f39c12" },
]

export function DashboardMockup() {
  const { resolvedTheme } = useTheme()
  const isDark = resolvedTheme === "dark"
  const [isSidebarOpen, setIsSidebarOpen] = useState(false)
  const controls = useAnimationControls()

  useEffect(() => {
    controls.start({
      backgroundPosition: ["0% 50%", "100% 50%", "0% 50%"],
    })
  }, [controls])

  const mirrorTextClass = `text-transparent bg-clip-text bg-gradient-to-r ${
    isDark ? "from-white to-black-600" : "from-gray-600 to-gray-200"
  }`

  const totalPrice = priceChartData.reduce((sum, item) => sum + item.price, 0)

  return (
    <>
      <motion.h2
        className={`text-xs md:text-xs font-light text-center mb-5 normalcase ${mirrorTextClass} relative z-20`}
        animate={controls}
        transition={{
          duration: "5",
          repeat: Number.POSITIVE_INFINITY,
          ease: "linear",
        }}
        style={{
          backgroundSize: "200% 100%",
        }}
      >
        "Preview only- final design may vary."
      </motion.h2>
      <motion.div
        initial="hidden"
        animate="visible"
        variants={containerVariants}
        className={`w-full max-w-[1200px] mx-auto rounded-xl overflow-hidden ${isDark ? "bg-zinc-900 shadow-2xl" : "bg-white shadow-xl"}`}
      >
        <div className="flex flex-col md:flex-row h-[600px] md:h-[800px]">
          {/* Mobile Dashboard Menu */}
          {isSidebarOpen && <MenuDashboard onClose={() => setIsSidebarOpen(false)} />}

          {/* Main Content */}
          <div className={`flex-1 ${isDark ? "bg-zinc-950" : "bg-white"} overflow-y-auto`}>
            {/* Header */}
            <motion.header
              variants={itemVariants}
              className={`h-16 border-b ${isDark ? "border-zinc-800" : "border-gray-200"} px-4 md:px-6 flex items-center justify-between sticky top-0 z-10 ${isDark ? "bg-zinc-950" : "bg-white"}`}
            >
              <div className="flex items-center gap-4 flex-1">
                <Button
                  variant="ghost"
                  size="icon"
                  className="md:hidden"
                  onClick={() => setIsSidebarOpen(!isSidebarOpen)}
                >
                  <Menu className="h-6 w-6" />
                </Button>
                <Search className={`w-4 h-4 ${isDark ? "text-gray-400" : "text-gray-500"}`} />
                <Input
                  type="search"
                  placeholder="Search trips, bookings, documents..."
                  className={`w-full max-w-md bg-transparent border-none text-xs ${isDark ? "placeholder-gray-500" : "placeholder-gray-400"}`}
                />
              </div>
              <div className="flex items-center gap-4">
                <Button variant="ghost" size="icon">
                  <Bell className={`w-4 h-4 ${isDark ? "text-gray-400" : "text-gray-600"}`} />
                </Button>
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/copilot_image_1732741355821-oo8gWX3NiQpzX0SN7BZqAEShDkTKaO.jpeg"
                  alt="Profile avatar"
                  width={40}
                  height={40}
                  className="rounded-lg object-cover"
                />
              </div>
            </motion.header>

            {/* Dashboard Content */}
            <div className="p-4 md:p-6 space-y-6">
              <motion.div
                variants={containerVariants}
                className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4"
              >
                {[
                  { title: "Total Trips", value: 6, subtitle: "Last 30 days", icon: Plane },
                  { title: "Upcoming Flights", value: 3, subtitle: "Next: BCN → JFK", icon: Calendar },
                  { title: "Hotel Nights", value: 8, subtitle: "Last 30 days", icon: BedDouble },
                  { title: "Travel Wallet", value: 2600, subtitle: "Last 30 days", icon: CreditCard, prefix: "$" },
                ].map((item, index) => (
                  <motion.div key={item.title} variants={itemVariants}>
                    <Card className={isDark ? "bg-zinc-900 border-zinc-800" : "bg-white border-gray-200"}>
                      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-xs font-medium text-foreground">{item.title}</CardTitle>
                        <item.icon className={`w-4 h-4 ${isDark ? "text-gray-400" : "text-gray-600"}`} />
                      </CardHeader>
                      <CardContent className="py-2">
                        <div className="text-2xl font-bold text-foreground flex items-baseline">
                          {item.prefix && <span className="text-lg mr-1">{item.prefix}</span>}
                          <AnimatedCounter end={item.value} />
                        </div>
                        <p className={`text-xs ${isDark ? "text-gray-500" : "text-gray-500"} mt-1`}>{item.subtitle}</p>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </motion.div>

              <motion.div variants={itemVariants}>
                <div className="text-center mb-6">
                  <h2 className="text-1xl font-semibold mb-2">Trip Details</h2>
                  <p className={`text-sm ${isDark ? "text-gray-400" : "text-gray-600"}`}>
                    Your upcoming journey details
                  </p>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
                  {[
                    {
                      image:
                        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/tesla-y-4d-suv-weiss-2021-PJENx9ayFbN66F34bRrohepLV664Ka.png",
                      alt: "Tesla Model Y",
                      title: "Tesla Model Y 2024",
                      details: [
                        "• Electric Car",
                        "• Premium Interior",
                        "• Airport Pickup Service",
                        "• 24/7 Customer Support",
                      ],
                      badge: "Suitpax Ride",
                      badgeColor: "bg-blue-400",
                    },
                    {
                      image: isDark
                        ? "https://www.fourseasons.com/alt/img-opt/~80.1112.0,0000-283,2624-3000,0000-1687,5000/publish/content/dam/fourseasons/images/web/NYF/NYF_1639_original.jpg"
                        : "https://www.fourseasons.com/alt/img-opt/~80.1112.0,0000-283,2624-3000,0000-1687,5000/publish/content/dam/fourseasons/images/web/NYF/NYF_1639_original.jpg",
                      alt: "Four Seasons Logo",
                      title: "Four Seasons Downtown",
                      details: [
                        "• Executive Suite with City View",
                        "• Plus Access",
                        "• 2 Nights • Breakfast Included",
                        "• Concierge Included",
                      ],
                      badge: "Suitpax Stays",
                      badgeColor: "bg-green-700",
                    },
                    {
                      image:
                        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/vejtnuxgocapfgfgk4ux.jpg-3jrWSfHAFZbDuPnSCTJeafIVKbw1r0.jpeg",
                      alt: "New York Skyline",
                      title: "New York City · AA2100",
                      details: ["• 15-18 January 2025", "• Financial District", "• WeWork Pass", "• IATA Summit"],
                      badge: "Suitpax Flights",
                      badgeColor: "bg-gray-600",
                    },
                  ].map((item, index) => (
                    <div key={index} className="w-full space-y-2">
                      <motion.div
                        className={`relative h-40 sm:h-48 rounded-lg overflow-hidden ${isDark ? "bg-zinc-800" : "bg-gray-100"}`}
                        whileHover={{ scale: 1.03 }}
                        transition={{ type: "spring", stiffness: 300, damping: 10 }}
                      >
                        <Image src={item.image || "/placeholder.svg"} alt={item.alt} fill className="object-cover" />
                        <div
                          className={`absolute top-1 left-1 ${item.badgeColor} text-white text-[10px] font-medium px-1.5 py-0.5 rounded-full`}
                        >
                          {item.badge}
                        </div>
                      </motion.div>
                      <div className="text-left">
                        <p className="text-sm font-medium mb-2">{item.title}</p>
                        <div className="grid grid-cols-2 gap-x-2 gap-y-1 text-left">
                          {item.details.map((detail, i) => (
                            <p key={i} className={`text-xs ${isDark ? "text-gray-400" : "text-gray-600"}`}>
                              {detail}
                            </p>
                          ))}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>

              <motion.div variants={containerVariants} className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                <motion.div variants={itemVariants} className="lg:col-span-2">
                  <ChartComponent />
                </motion.div>

                <motion.div variants={itemVariants}>
                  <Card className={isDark ? "bg-zinc-900 border-zinc-800" : "bg-white border-gray-200"}>
                    <CardHeader className="flex justify-between items-center">
                      <div>
                        <CardTitle className="text-xs text-center justify text-foreground">Upcoming Travel</CardTitle>
                        <CardDescription className={`text-xs ${isDark ? "text-gray-400" : "text-gray-600"}`}>
                          Your next 30 days of travel
                        </CardDescription>
                      </div>
                      <motion.div
                        initial={{ opacity: 0, scale: 0.5 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ duration: 0.5 }}
                      >
                        <motion.div
                          animate={{
                            rotate: 360,
                            transition: { duration: 1, repeat: Number.POSITIVE_INFINITY, ease: "linear" },
                          }}
                        >
                          <Loader2 className="w-5 h-5 text-green-400" />
                        </motion.div>
                      </motion.div>
                    </CardHeader>
                    <CardContent>
                      <motion.div variants={containerVariants} className="space-y-4">
                        {[
                          {
                            icon: Plane,
                            title: "BCN → NYC",
                            subtitle: "Business Class · AA2100",
                            date: "Jan 15",
                            time: "14:55",
                            badge: <FlightBadge from="Barcelona" to="New York" isDark={isDark} />,
                            progress: 60,
                          },
                          {
                            icon: BedDouble,
                            title: "Four Seasons NYC",
                            subtitle: "Executive Suite · 2 nights",
                            date: "Jan 15-18",
                            time: "Check-in: 15:00",
                            progress: 0,
                          },
                          {
                            icon: Car,
                            title: "Suitpax Ride",
                            subtitle: "Tesla Model Y",
                            date: "Jan 15",
                            time: "13:30",
                            progress: 0,
                          },
                        ].map((item, index) => (
                          <motion.div key={index} variants={itemVariants} className={`flex items-center gap-4`}>
                            <div
                              className={`w-10 h-10 rounded-full ${isDark ? "bg-gray80" : "bg-gray-200"} flex items-center justify-center`}
                            >
                              <item.icon className={`w-5 h-5 ${isDark ? "text-gray-300" : "text-gray-600"}`} />
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center justify-between mb-1 gap-1">
                                <h4 className="text-xs font-medium text-foreground truncate">{item.title}</h4>
                                {item.badge && <div className="flex-shrink-1">{item.badge}</div>}
                              </div>
                              <p className={`text-[10px] ${isDark ? "text-gray-400" : "text-gray-600"} truncate`}>
                                {item.subtitle}
                              </p>
                              {item.progress > 0 && (
                                <div className="mt-1 h-1 w-full bg-gray-200 rounded-full overflow-hidden">
                                  <motion.div
                                    className="h-full bg-green-500"
                                    initial={{ width: 0 }}
                                    animate={{ width: `${item.progress}%` }}
                                    transition={{ duration: 1, ease: "easeInOut" }}
                                  />
                                </div>
                              )}
                            </div>
                            <div className="text-right flex-shrink-0">
                              <div className="text-xs font-medium text-foreground">{item.date}</div>
                              <div className={`text-[10px] ${isDark ? "text-gray-400" : "text-gray-600"}`}>
                                {item.time}
                              </div>
                            </div>
                          </motion.div>
                        ))}
                      </motion.div>
                    </CardContent>
                  </Card>
                </motion.div>
              </motion.div>

              <motion.div variants={itemVariants}>
                <Card className={isDark ? "bg-zinc-900 border-zinc-800" : "bg-white border-gray-200"}>
                  <CardHeader>
                    <CardTitle className="text-xs text-foreground">Quick Actions</CardTitle>
                    <CardDescription className={`text-xs ${isDark ? "text-gray-400" : "text-gray-600"}`}>
                      Common travel tasks
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <motion.div variants={containerVariants} className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                      {[
                        { icon: Calendar, label: "Book a Flight" },
                        { icon: BedDouble, label: "Reserve Hotel" },
                        { icon: Car, label: "Schedule Ride" },
                        { icon: CreditCard, label: "Manage Expenses" },
                        { icon: Briefcase, label: "Business Trip" },
                        { icon: Clock, label: "View History" },
                      ].map((item, index) => (
                        <motion.div key={item.label} variants={itemVariants}>
                          <Button
                            variant="outline"
                            className={`w-full justify-start gap-2 ${
                              isDark
                                ? "text-gray-300 border-gray-700 hover:bg-zinc-800"
                                : "text-gray-700 border-gray-300 hover:bg-gray-50"
                            }`}
                          >
                            <item.icon className="w-3 h-3" /> <span className="text-[10px]">{item.label}</span>
                          </Button>
                        </motion.div>
                      ))}
                    </motion.div>
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div variants={itemVariants}>
                <Card className={isDark ? "bg-zinc-900 border-zinc-800" : "bg-white border-gray-200"}>
                  <CardHeader>
                    <CardTitle className="text-xs text-foreground">Air Wallet</CardTitle>
                    <CardDescription className={`text-xs ${isDark ? "text-gray-400" : "text-gray-600"}`}>
                      Breakdown of your travel costs
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <HorizontalPriceChart items={priceChartData} total={totalPrice} />
                  </CardContent>
                </Card>
              </motion.div>
            </div>
          </div>
        </div>
      </motion.div>
    </>
  )
}

