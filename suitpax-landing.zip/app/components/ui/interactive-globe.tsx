"use client"

import { useEffect, useRef, useMemo } from "react"
import createGlobe from "cobe"
import { useSpring } from "framer-motion"
import { GLOBE_CONFIG } from "@/app/config/globe-config"

// Configuration options
// const GLOBE_CONFIG = {
//   width: 1000,
//   height: 1000,
//   scale: 1,
//   maxScale: 1.5,
//   minScale: 0.5,
//   baseColor: [0.1, 0.1, 0.1],
//   markerColor: [0.58, 0.77, 0.45], // #93c572 in RGB
//   glowColor: [0.58, 0.77, 0.45],
//   mapBrightness: 6,
//   baseRotationSpeed: 0.003,
//   markers: [
//     { location: [37.0902, -95.7129], size: 0.1 }, // North America
//     { location: [54.526, 15.2551], size: 0.1 }, // Europe
//     { location: [34.0479, 100.6197], size: 0.1 }, // Asia
//     { location: [-8.7832, -55.4915], size: 0.1 }, // South America
//     { location: [9.1021, 18.2812], size: 0.1 }, // Africa
//     { location: [-25.2744, 133.7751], size: 0.1 }, // Australia
//     { location: [61.524, 105.3188], size: 0.1 }, // Russia
//     { location: [20.5937, 78.9629], size: 0.1 }, // India
//     { location: [35.8617, 104.1954], size: 0.1 }, // China
//     { location: [-14.235, -51.9253], size: 0.1 }, // Brazil
//   ],
//   heatmapData: [
//     { location: [37.0902, -95.7129], value: 1 }, // North America
//     { location: [54.526, 15.2551], value: 0.8 }, // Europe
//     { location: [34.0479, 100.6197], value: 0.9 }, // Asia
//     { location: [-8.7832, -55.4915], value: 0.6 }, // South America
//     { location: [9.1021, 18.2812], value: 0.5 }, // Africa
//     { location: [-25.2744, 133.7751], value: 0.7 }, // Australia
//   ],
// }

interface InteractiveGlobeProps {
  showHeatmap?: boolean
}

export function InteractiveGlobe({ showHeatmap = false }: InteractiveGlobeProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const pointerInteracting = useRef<number | null>(null)
  const pointerInteractionMovement = useRef(0)
  const phi = useSpring(0)

  const markers = useMemo(() => GLOBE_CONFIG.markers, [])
  const heatmapData = useMemo(() => GLOBE_CONFIG.heatmapData, [])

  useEffect(() => {
    let width = 0
    let currentPhi = 0
    let globe: ReturnType<typeof createGlobe>

    const onResize = () => {
      if (canvasRef.current) {
        width = canvasRef.current.offsetWidth
      }
    }
    window.addEventListener("resize", onResize)
    onResize()

    if (canvasRef.current) {
      globe = createGlobe(canvasRef.current, {
        devicePixelRatio: 2,
        width: width * 2,
        height: width * 2,
        phi: 0,
        theta: 0.3,
        dark: 1,
        diffuse: 1.2,
        mapSamples: 16000,
        mapBrightness: GLOBE_CONFIG.mapBrightness,
        baseColor: GLOBE_CONFIG.baseColor,
        markerColor: GLOBE_CONFIG.markerColor,
        glowColor: GLOBE_CONFIG.glowColor,
        markers: markers,
        scale: GLOBE_CONFIG.scale,
        maxScale: GLOBE_CONFIG.maxScale,
        minScale: GLOBE_CONFIG.minScale,
        onRender: (state) => {
          if (!pointerInteracting.current) {
            currentPhi += GLOBE_CONFIG.baseRotationSpeed
          }
          state.phi = currentPhi + pointerInteractionMovement.current
          phi.set(state.phi)
          state.width = width * 2
          state.height = width * 2
        },
      })
    }

    if (showHeatmap && globe) {
      globe.heatmap(heatmapData)
    }

    return () => {
      if (globe) {
        globe.destroy()
      }
      window.removeEventListener("resize", onResize)
    }
  }, [phi, markers, heatmapData, showHeatmap])

  return (
    <div className="relative w-full h-full">
      <canvas
        ref={canvasRef}
        className="w-full h-full"
        onPointerDown={(e) => {
          pointerInteracting.current = e.clientX - pointerInteractionMovement.current
          canvasRef.current!.style.cursor = "grabbing"
        }}
        onPointerUp={() => {
          pointerInteracting.current = null
          canvasRef.current!.style.cursor = "grab"
        }}
        onPointerOut={() => {
          pointerInteracting.current = null
          canvasRef.current!.style.cursor = "grab"
        }}
        onMouseMove={(e) => {
          if (pointerInteracting.current !== null) {
            const delta = e.clientX - pointerInteracting.current
            pointerInteractionMovement.current = delta * 0.01
            canvasRef.current!.style.cursor = "grabbing"
          }
        }}
        onTouchMove={(e) => {
          if (pointerInteracting.current !== null && e.touches[0]) {
            const delta = e.touches[0].clientX - pointerInteracting.current
            pointerInteractionMovement.current = delta * 0.01
          }
        }}
      />
    </div>
  )
}

