import * as React from "react"
import { Slot } from "@radix-ui/react-slot"
import { cva, type VariantProps } from "class-variance-authority"
import { cn } from "@/app/lib/utils"

// Definición de variantes de botón con `cva` (class-variance-authority).
// Esto permite crear diferentes estilos de botón que cambian dependiendo de las props que se le pasen.
const buttonVariants = cva(
  "inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50", // Clases comunes a todos los botones
  {
    variants: {
      // Variantes de estilo (color y comportamiento visual)
      variant: {
        // Estilo por defecto del botón: Fondo verde claro con texto negro.
        default: "bg-emerald-400 text-white hover:bg-emerald-500/90",

        // Estilo destructivo: Fondo rojo con texto claro, ideal para botones peligrosos.
        destructive: "bg-red-600 text-white hover:bg-red-700/90",

        // Estilo outline: Botón con borde, fondo transparente, texto oscuro. Al pasar el ratón cambia a un color de acento.
        outline: "border border-input bg-background hover:bg-accent hover:text-accent-foreground",

        // Estilo secundario: Fondo gris con texto oscuro, hover ligeramente oscuro.
        secondary: "bg-gray-500 text-white hover:bg-gray-600/80",

        // Estilo ghost: Fondo transparente y texto del color de acento, con efecto de hover.
        ghost: "hover:bg-accent hover:text-accent-foreground",

        // Estilo de enlace: Solo texto, subrayado, y al pasar el ratón se subraya.
        link: "text-emerald-400 underline-offset-4 hover:underline",
      },

      // Variantes de tamaño del botón
      size: {
        // Tamaño por defecto del botón: altura de 10 unidades, padding horizontal de 4 y vertical de 2.
        default: "h-10 px-4 py-2",

        // Tamaño pequeño: altura de 9 unidades, padding de 3.
        sm: "h-9 rounded-md px-3",

        // Tamaño grande: altura de 11 unidades, padding de 8.
        lg: "h-11 rounded-md px-8",

        // Tamaño ícono: un botón cuadrado con solo 10 unidades de alto y ancho.
        icon: "h-10 w-10", // Ideal para botones con íconos
      },
    },

    // Valores predeterminados para las variantes si no se pasan como props
    defaultVariants: {
      variant: "default", // Si no se especifica `variant`, se usará el `default`
      size: "default", // Si no se especifica `size`, se usará el `default`
    },
  },
)

// Interfaz para las props del botón, que extiende tanto las props estándar de un botón HTML como las variantes definidas
export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean // Permite decidir si el botón es un `Slot` o un botón estándar
}

// Componente Button utilizando `React.forwardRef` para pasar la referencia a un componente hijo si es necesario.
const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    // Determina si se debe renderizar como un `Slot` o como un `button` estándar.
    const Comp = asChild ? Slot : "button"

    // Renderiza el componente con las clases correspondientes y las props pasadas
    return (
      <Comp
        className={cn(buttonVariants({ variant, size, className }))} // Aplica las clases de las variantes + cualquier clase personalizada
        ref={ref} // Pasa la referencia del botón
        {...props} // Pasa las props restantes del botón (onClick, disabled, etc.)
      />
    )
  },
)
Button.displayName = "Button" // Asignamos el nombre al componente para depuración y mejores mensajes de error

// Exportamos el componente y las variantes para poder utilizarlos en otros archivos.
export { Button, buttonVariants }

