"use client"
import React from "react"

interface CountdownTimerProps {
  targetDate: Date
}

export const CountdownTimer: React.FC<CountdownTimerProps> = ({ targetDate }) => {
  const [timeLeft, setTimeLeft] = React.useState<number>(0)

  React.useEffect(() => {
    const calculateTimeLeft = () => {
      const now = new Date()
      const difference = targetDate.getTime() - now.getTime()
      setTimeLeft(difference > 0 ? difference : 0)
    }

    calculateTimeLeft()
    const interval = setInterval(calculateTimeLeft, 1000)
    return () => clearInterval(interval)
  }, [targetDate])

  const formatTime = (milliseconds: number) => {
    const seconds = Math.floor((milliseconds / 1000) % 60)
    const minutes = Math.floor((milliseconds / (1000 * 60)) % 60)
    const hours = Math.floor((milliseconds / (1000 * 60 * 60)) % 24)
    const days = Math.floor(milliseconds / (1000 * 60 * 60 * 24))

    return `${days}d ${hours}h ${minutes}m ${seconds}s`
  }

  if (timeLeft <= 0) {
    return <span className="text-emerald-400 text-sm sm:text-base md:text-lg lg:text-xl">Launched!</span>
  }

  return (
    <div className="inline-flex items-center gap-2 rounded-full px-3 py-2 text-xs font-medium text-black transition-all duration-200 bg-gradient-to-r from-gray-300 to-gray-300 backdrop-filter backdrop-blur-sm">
      <span className="mr-2 text-black">Launching in:</span> <span className="text-black">{formatTime(timeLeft)}</span>
    </div>
  )
}

