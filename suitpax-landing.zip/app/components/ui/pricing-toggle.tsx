"use client"

import { Switch } from "@/components/ui/switch"
import { motion } from "framer-motion"
import type { PricingToggleProps } from "@/types/pricing"

export function PricingToggle({ isAnnual, onToggle }: PricingToggleProps) {
  return (
    <div className="flex items-center justify-center gap-3 mb-8 bg-gray-50/50 backdrop-blur-sm rounded-full p-2 max-w-fit mx-auto">
      <span className={`text-sm ${isAnnual ? "text-gray-500" : "text-gray-900 font-medium"}`}>Monthly</span>
      <Switch
        checked={isAnnual}
        onCheckedChange={onToggle}
        className="data-[state=checked]:bg-blue-500 w-[42px] h-[24px]"
      />
      <span className={`text-sm ${isAnnual ? "text-gray-900 font-medium" : "text-gray-500"}`}>
        Annual <span className="text-blue-500">(Save 20%)</span>
      </span>
    </div>
  )
}

