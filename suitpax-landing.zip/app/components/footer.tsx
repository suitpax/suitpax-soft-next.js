import Link from "next/link"
import { FaTwitter, FaLinkedin, FaGithub, FaInstagram } from "react-icons/fa"
import Image from "next/image"

const footerLinks = {
  Product: [
    { name: "Features", href: "/features" },
    { name: "Security", href: "/security" },
    { name: "Enterprise", href: "/enterprise" },
    { name: "Pricing", href: "/pricing" },
  ],
  Resources: [
    { name: "Documentation", href: "/docs" },
    { name: "API", href: "/api" },
    { name: "Guideline", href: "/guideline" },
    { name: "Blog", href: "/blog" },
    {
      name: "System Status",
      href: "https://status.suitpax.com",
      external: true,
    },
  ],
  Company: [
    { name: "About", href: "/about" },
    { name: "Careers", href: "/careers" },
    { name: "Contact", href: "/contact" },
    { name: "Partners", href: "/partners" },
  ],
  Legal: [
    { name: "Privacy", href: "/privacy" },
    { name: "Terms", href: "/terms" },
    { name: "Security", href: "/security" },
    { name: "Compliance", href: "/compliance" },
  ],
}

export function Footer() {
  return (
    <footer className="bg-gray-200 text-emerald-950">
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-8">
          <Image src="/suitpax-main-logo.svg" alt="Suitpax" width={170} height={35} className="h-7 w-auto" />
          <iframe
            src="https://status.suitpax.com/badge?theme=light"
            width="240"
            height="30"
            frameBorder="2"
            scrolling="no"
            style={{ colorScheme: "normal" }}
            title="Suitpax Status"
          ></iframe>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-8">
          {Object.entries(footerLinks).map(([category, links], index) => (
            <div key={category}>
              <h3 className="text-sm font-semibold mb-4">{category}</h3>
              <ul className="space-y-2">
                {links.map((link) => (
                  <li key={link.name}>
                    {link.name === "Contact" ? (
                      <Link
                        href={link.href}
                        className="text-sm hover:text-black transition-colors flex items-center gap-2"
                        {...(link.external ? { target: "_blank", rel: "noopener noreferrer" } : {})}
                      >
                        {link.name}
                        {link.name === "System Status" && (
                          <span className="inline-block w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                        )}
                      </Link>
                    ) : (
                      <Link
                        href={link.href === "/contact" ? "/contact" : link.href}
                        className="text-sm hover:text-black transition-colors flex items-center gap-2"
                        {...(link.external ? { target: "_blank", rel: "noopener noreferrer" } : {})}
                      >
                        {link.name}
                      </Link>
                    )}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div className="border-t border-gray-600 pt-7">
          <div className="flex flex-col md:flex-row justify-between items-center text-center md:text-left">
            <div className="text-sm mb-4 md:mb-0">
              <p>©{new Date().getFullYear()} Suitpax. All rights reserved.</p>
              <p className="text-xs text-gray-600">
                "Suitpax" and logo are registered trademarks of the company. Suitpax trademarks and brands are
                registered with WIPO and EUIPO.
              </p>
            </div>
            <div className="flex space-x-6">
              <Link href="https://instagram.com/suitpax" className="hover:text-black transition-colors">
                <FaInstagram size={16} />
                <span className="sr-only">Instagram</span>
              </Link>
              <Link href="https://twitter.com/Suitpax" className="hover:text-black transition-colors">
                <FaTwitter size={16} />
                <span className="sr-only">X (Twitter)</span>
              </Link>
              <Link href="https://linkedin.com/company/Suitpax" className="hover:text-black transition-colors">
                <FaLinkedin size={16} />
                <span className="sr-only">LinkedIn</span>
              </Link>
              <Link href="https://github.com/suitpax" className="hover:text-black transition-colors">
                <FaGithub size={16} />
                <span className="sr-only">GitHub</span>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}

