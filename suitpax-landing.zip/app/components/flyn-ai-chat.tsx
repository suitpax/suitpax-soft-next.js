import { SendIcon, MapPinIcon } from "@heroicons/react/24/outline" // Imported from Heroicons

// ...
;(<SendIcon className="h-4 w-4 ml-2" />) <
  // ...

  MapPinIcon
className="h-4 w-4 mr-2" />

// ...

