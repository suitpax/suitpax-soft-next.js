"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { createSvixApplication, createSvixEndpoint, sendSvixMessage } from "@/app/lib/svix"

export function SvixDemo() {
  const [appName, setAppName] = useState("")
  const [appId, setAppId] = useState("")
  const [endpointUrl, setEndpointUrl] = useState("")
  const [message, setMessage] = useState("")

  const handleCreateApp = async () => {
    try {
      const app = await createSvixApplication(appName)
      setAppId(app.id)
      alert(`Application created with ID: ${app.id}`)
    } catch (error) {
      alert("Error creating application")
    }
  }

  const handleCreateEndpoint = async () => {
    if (!appId) {
      alert("Please create an application first")
      return
    }
    try {
      const endpoint = await createSvixEndpoint(appId, endpointUrl)
      alert(`Endpoint created with ID: ${endpoint.id}`)
    } catch (error) {
      alert("Error creating endpoint")
    }
  }

  const handleSendMessage = async () => {
    if (!appId) {
      alert("Please create an application first")
      return
    }
    try {
      const sentMessage = await sendSvixMessage(appId, "test.event", { message })
      alert(`Message sent with ID: ${sentMessage.id}`)
    } catch (error) {
      alert("Error sending message")
    }
  }

  return (
    <div className="space-y-4 p-4 bg-white rounded-lg shadow">
      <h2 className="text-2xl font-bold mb-4">Svix Demo</h2>
      <div>
        <Input
          type="text"
          placeholder="Application Name"
          value={appName}
          onChange={(e) => setAppName(e.target.value)}
        />
        <Button onClick={handleCreateApp} className="mt-2">
          Create Application
        </Button>
      </div>
      <div>
        <Input
          type="text"
          placeholder="Endpoint URL"
          value={endpointUrl}
          onChange={(e) => setEndpointUrl(e.target.value)}
        />
        <Button onClick={handleCreateEndpoint} className="mt-2">
          Create Endpoint
        </Button>
      </div>
      <div>
        <Input type="text" placeholder="Message" value={message} onChange={(e) => setMessage(e.target.value)} />
        <Button onClick={handleSendMessage} className="mt-2">
          Send Message
        </Button>
      </div>
    </div>
  )
}

