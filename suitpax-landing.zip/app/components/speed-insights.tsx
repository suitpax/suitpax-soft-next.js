"use client"

import { SpeedInsights } from "@vercel/speed-insights/next"

export function VercelSpeedInsights() {
  return <SpeedInsights />
}

