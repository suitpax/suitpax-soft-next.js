"use client"
import Link from "next/link"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import Image from "next/image"
import { ArrowRightOnRectangleIcon } from "@heroicons/react/24/outline"
import { useStore } from "@/app/store/useStore"
import { BarsButton } from "@/app/components/ui/bars-button"
import { useTheme } from "next-themes"

interface HeaderProps {
  onMenuToggle: () => void
}

export function Header({ onMenuToggle }: HeaderProps) {
  const { resolvedTheme } = useTheme()
  const isDark = resolvedTheme === "dark"

  const gradient = isDark
    ? "bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500"
    : "bg-gradient-to-r from-emerald-600 to-emerald-800"

  const textColor = isDark ? "text-white" : "text-white"

  const { user, logout } = useStore()

  return (
    <motion.header
      className="fixed top-0 w-full z-50 bg-black/80 backdrop-filter backdrop-blur-lg"
      initial={{ y: -50 }} // Reduced initial y for smoother animation
      animate={{ y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <motion.div
        className="container mx-auto flex h-14 items-center border-b border-transparent px-4 sm:px-6 lg:px-8"
        initial={{ y: -50 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <Link href="/" className="font-bold text-white flex items-center">
          <Image
            src="/suitpax-cloud-logo.svg"
            alt="Suitpax"
            width={170}
            height={35}
            className="h-7 w-auto" // Fixed logo size
          />
        </Link>
        <div className="flex items-center justify-end flex-1 ml-4 w-full md:w-auto">
          <div className="flex items-center space-x-2">
            <Button
              className="bg-white text-black hover:bg-white/90 rounded-md px-2 py-1.5 text-xs sm:text-sm md:text-base h-6 sm:h-8 md:h-10 lg:h-8 transition-all duration-300 ease-linear" // Adjusted button size for larger screens
              asChild
            >
              {user.isLoggedIn ? (
                <span onClick={logout} className="flex items-center">
                  <ArrowRightOnRectangleIcon className="w-4 h-4 mr-2" />
                  {user.name}
                </span>
              ) : (
                <Link href="/auth/sign-up" className="flex items-center">
                  Get started
                </Link>
              )}
            </Button>
          </div>
        </div>
        <BarsButton onClick={onMenuToggle} className="ml-2" /> {/* Always show BarsButton */}
      </motion.div>
    </motion.header>
  )
}

