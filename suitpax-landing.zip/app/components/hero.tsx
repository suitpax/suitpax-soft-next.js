"use client"
import { motion } from "framer-motion"
import { CalendarIcon } from "@radix-ui/react-icons"
import { RainbowButton } from "@/app/components/ui/rainbow-button"
import { CountdownTimer } from "@/app/components/ui/countdown-timer"
import { useTheme } from "next-themes"
import { DashboardMockup } from "@/app/components/ui/dashboard-mockup"

export function Hero() {
  const { resolvedTheme } = useTheme()

  const mirrorTextClass = `text-transparent bg-clip-text bg-gradient-to-r ${resolvedTheme === "dark" ? "from-gray-200 to-black-600" : "from-gray-900 to-gray-200"}`
  const isDark = resolvedTheme === "dark"

  const targetDate = new Date("2025-06-01T12:00:00Z")
  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-black via-emerald-950 to-emerald-900 to-black/95">
      <div className="container relative z-10 mx-auto flex flex-col-reverse lg:flex-row items-center justify-center min-h-[calc(100vh-80px)] px-4 py-24 sm:px-6 lg:px-8 lg:py-36 lg:min-h-[calc(100vh-120px)]">
        <div className="flex flex-col items-center lg:items-start text-center lg:text-left w-full lg:w-1/2 space-y-8 lg:space-y-12">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
            <div className="mb-8 sm:mb-12 relative flex justify-center lg:justify-start">
              <motion.div className="relative" initial="initial" animate="animate" whileHover="hover">
                <motion.span
                  className="absolute inset-0 rounded-full bg-gradient-to-r from-emerald-400 to-emerald-600"
                  variants={{
                    initial: { opacity: 0, scale: 0.95 },
                    animate: { opacity: 1, scale: 1 },
                  }}
                />
                <motion.span
                  className="absolute inset-0 rounded-full bg-gradient-to-r from-gray-400 to-emerald-900 blur-sm"
                  variants={{
                    initial: { opacity: 0 },
                    animate: { opacity: 0.7 },
                    hover: { opacity: 1 },
                  }}
                />
                <RainbowButton
                  href="https://cal.com/suitpax/alberto-zurano"
                  className="relative inline-flex items-center rounded-full h-auto px-3 py-1.5 text-xs sm:text-sm font-medium text-black transition-all duration-200"
                >
                  <CalendarIcon className="h-4 w-4 mr-2" />
                  <span className="mr-2">Schedule a call</span>
                </RainbowButton>
              </motion.div>
            </div>
          </motion.div>

          {/* Hero content */}
          <div>
            <motion.h2
              className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold text-center lg:text-left mb-5 text-gray-300 tracking-tighter normalcase relative z-20"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
            >
              Where travel <br /> meets intelligence
            </motion.h2>
            <motion.p
              className="text-sm sm:text-base md:text-lg lg:text-xl text-gray-100 max-w-2xl mx-auto lg:mx-0 mb-6 sm:mb-8 text-center lg:text-left"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
            >
              Transform your travel operations with AI-powered solutions. Experience seamless integration and
              unprecedented efficiency.
            </motion.p>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="relative group w-full sm:w-auto flex justify-center lg:justify-start"
            >
              <CountdownTimer targetDate={targetDate} />
            </motion.div>
          </div>

          {/* Dashboard mockup */}
          <div className="mt-10 lg:mt-20 w-full max-w-4xl mx-auto aspect-square overflow-hidden rounded-2xl relative">
            <DashboardMockup />
          </div>
        </div>
      </div>
    </section>
  )
}

