"use client"

import { LogoCarousel } from "@/app/components/ui/logo-carousel"
import { Card, CardContent } from "@/app/components/ui/card"

const demoLogos = [
  { id: 1, name: "Dub", src: "https://www.prismui.tech/logo/dub.svg" },
  { id: 2, name: "Supabase", src: "https://www.prismui.tech/logo/supabase.svg" },
  { id: 3, name: "Vercel", src: "https://www.prismui.tech/logo/vercel.svg" },
  { id: 4, name: "Resend", src: "https://www.prismui.tech/logo/resend.svg" },
  {
    id: 6,
    name: "New Logo 1",
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/logo%20(3)-x0lMl5ZDI5wGce0YAxUfujIZ0Rn4al.svg",
  },
  {
    id: 7,
    name: "New Logo 2",
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/id5jJFQysJ-VuYAlVV3dammq13MyM1dVd4IYhrhEy.svg",
  },
  {
    id: 8,
    name: "New Logo 3",
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/idLgONrQIi-zV1BvVWqNGJL8l8meo8XXSbn2M6i8v.svg",
  },
  {
    id: 9,
    name: "New Logo 4",
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/logo%20(4)-OObZf0cBFQ58wdE4tVFuhoiB19eT1u.svg",
  },
  {
    id: 10,
    name: "New Logo 5",
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/logo%20(5)-hhMQjjN0Gu1EQsGW2ZTB9ujaM6k376.svg",
  },
]

export function PartnersSlider() {
  return (
    <Card size="xl" className="flex flex-col justify-center items-center">
      <CardContent className="pt-10 w-full">
        <div className="text-center space-y-6 mb-12">
          <p className="text-xs font-medium tracking-tighter text-muted-foreground">
            TRUSTED BY TEAMS FROM AROUND THE WORLD
          </p>
          <h2 className="text-2xl font-medium tracking-tighter leading-none">
            Trusted by 5,000+ <br /> to elevate travel
          </h2>
        </div>
        <LogoCarousel logos={demoLogos} />
      </CardContent>
    </Card>
  )
}

