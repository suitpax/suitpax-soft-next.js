"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { motion, AnimatePresence } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { cn } from "@/lib/utils"
import { ChevronLeft, Eye, EyeOff, Facebook, Twitter, Linkedin, Github, Instagram } from "lucide-react"
import { useStore } from "@/app/store/useStore"

const CONTAINER_MAX_WIDTH = "320px"
const LOGO_SIZE = 170
const BUTTON_HEIGHT = "40px"

const buttonStyles = {
  google: "bg-gray-300 hover:bg-[#5E6AD2]/90 text-green-950 border-0",
  default: "bg-transparent hover:bg-white/5 text-white border-white/10",
}

const linkStyles = "text-gray-400 hover:text-white transition-colors"

type SignUpMethod = "initial" | "google" | "email" | "saml"

export default function SignUpPage() {
  const [signUpMethod, setSignUpMethod] = useState<SignUpMethod>("initial")
  const [showPassword, setShowPassword] = useState(false)
  const [formData, setFormData] = useState({
    email: "",
    firstName: "",
    lastName: "",
    password: "",
    confirmPassword: "",
  })

  const { setUser } = useStore()

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setUser({
      name: `${formData.firstName} ${formData.lastName}`,
      email: formData.email,
      isLoggedIn: true,
    })
    setFormData({
      email: "",
      firstName: "",
      lastName: "",
      password: "",
      confirmPassword: "",
    })
    setSignUpMethod("initial")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-900 via-emerald-800 to-emerald-950 flex flex-col items-center justify-center p-4 pb-8">
      <div className="w-full mx-auto space-y-6" style={{ maxWidth: CONTAINER_MAX_WIDTH }}>
        {/* Logo & Title */}
        <div className="text-center space-y-6">
          <Image
            src="/suitpax-cloud-logo.svg"
            alt="Suitpax"
            width={LOGO_SIZE}
            height={LOGO_SIZE * 0.8}
            className="mx-auto"
            priority
          />
        </div>

        <AnimatePresence mode="wait">
          {signUpMethod === "initial" && (
            <motion.div
              key="initial"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
            >
              <div className="space-y-3">
                {[
                  { text: "Continue with Google", variant: "google", method: "google" },
                  { text: "Continue with email", variant: "default", method: "email" },
                  { text: "Continue with SAML SSO", variant: "default", method: "saml" },
                ].map((button) => (
                  <Button
                    key={button.text}
                    variant="outline"
                    className={cn(
                      "w-full font-normal text-sm transition-all duration-200",
                      buttonStyles[button.variant as keyof typeof buttonStyles],
                    )}
                    style={{ height: BUTTON_HEIGHT }}
                    onClick={() => setSignUpMethod(button.method as SignUpMethod)}
                  >
                    {button.text}
                  </Button>
                ))}
              </div>
            </motion.div>
          )}

          {signUpMethod !== "initial" && (
            <motion.div
              key="form"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
              className="relative backdrop-blur-xl bg-white/10 rounded-2xl p-8 shadow-xl border border-white/20"
            >
              <Button
                type="button"
                variant="ghost"
                className="text-white mb-6"
                onClick={() => setSignUpMethod("initial")}
              >
                <ChevronLeft className="mr-2 h-4 w-4" />
                Back
              </Button>

              <h2 className="text-xl text-white font-medium mb-6">Create your account</h2>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="firstName" className="text-white">
                      First Name
                    </Label>
                    <Input
                      id="firstName"
                      name="firstName"
                      type="text"
                      placeholder="First Name"
                      value={formData.firstName}
                      onChange={handleInputChange}
                      required
                      className="bg-white/10 text-white border-white/20 placeholder:text-white/50"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="lastName" className="text-white">
                      Last Name
                    </Label>
                    <Input
                      id="lastName"
                      name="lastName"
                      type="text"
                      placeholder="Last Name"
                      value={formData.lastName}
                      onChange={handleInputChange}
                      required
                      className="bg-white/10 text-white border-white/20 placeholder:text-white/50"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email" className="text-white">
                    Email Address
                  </Label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    placeholder="Enter your email"
                    value={formData.email}
                    onChange={handleInputChange}
                    required
                    className="bg-white/10 text-white border-white/20 placeholder:text-white/50"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="password" className="text-white">
                    Password
                  </Label>
                  <div className="relative">
                    <Input
                      id="password"
                      name="password"
                      type={showPassword ? "text" : "password"}
                      placeholder="Create a password"
                      value={formData.password}
                      onChange={handleInputChange}
                      required
                      className="bg-white/10 text-white border-white/20 placeholder:text-white/50 pr-10"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-white/50 hover:text-white"
                    >
                      {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                </div>

                <Button type="submit" className="w-full bg-emerald-500 hover:bg-emerald-600 text-white">
                  Create Account
                </Button>

                <div className="relative my-6">
                  <div className="absolute inset-0 flex items-center">
                    <div className="w-full border-t border-white/20"></div>
                  </div>
                  <div className="relative flex justify-center text-sm">
                    <span className="px-2 bg-emerald-900/50 text-white/70">OR</span>
                  </div>
                </div>

                <Button type="button" variant="outline" className="w-full border-white/20 text-white hover:bg-white/10">
                  Continue with passkeys
                </Button>
              </form>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Footer Links */}
        <div className="text-center space-y-6">
          <p className="text-sm text-gray-400">
            Already have an account?{" "}
            <Link href="/auth/sign-in" className={linkStyles}>
              Sign in
            </Link>
          </p>
        </div>
      </div>

      {/* Social Links */}
      <div className="w-full mt-8 text-center">
        <div className="flex justify-center space-x-4 mb-4">
          <Link href="https://facebook.com/suitpax" className="text-gray-400 hover:text-white transition-colors">
            <Facebook className="h-5 w-5 text-gray-400 hover:text-white transition-colors" />
          </Link>
          <Link href="https://twitter.com/suitpax" className="text-gray-400 hover:text-white transition-colors">
            <Twitter className="h-5 w-5 text-gray-400 hover:text-white transition-colors" />
          </Link>
          <Link
            href="https://linkedin.com/company/suitpax"
            className="text-gray-400 hover:text-white transition-colors"
          >
            <Linkedin className="h-5 w-5 text-gray-400 hover:text-white transition-colors" />
          </Link>
          <Link href="https://github.com/suitpax" className="text-gray-400 hover:text-white transition-colors">
            <Github className="h-5 w-5 text-gray-400 hover:text-white transition-colors" />
          </Link>
          <Link href="https://instagram.com/suitpax" className="text-gray-400 hover:text-white transition-colors">
            <Instagram className="h-5 w-5 text-gray-400 hover:text-white transition-colors" />
          </Link>
        </div>
        <p className="text-sm text-gray-500">© {new Date().getFullYear()} Suitpax. All rights reserved.</p>
      </div>
    </div>
  )
}

