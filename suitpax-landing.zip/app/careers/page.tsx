"use client"

import { motion } from "framer-motion"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { ArrowRight, Building2, Users2, Rocket, Globe2 } from "lucide-react"
import { useTheme } from "next-themes"

const benefits = [
  {
    icon: Globe2,
    title: "Global Impact",
    description: "Shape the future of travel technology and make a difference worldwide",
  },
  {
    icon: Users2,
    title: "Diverse Team",
    description: "Join a multicultural team of passionate innovators",
  },
  {
    icon: Rocket,
    title: "Fast Growth",
    description: "Be part of a rapidly expanding travel tech company",
  },
  {
    icon: Building2,
    title: "Modern Workplace",
    description: "Flexible work arrangements and cutting-edge tools",
  },
]

export default function CareersPage() {
  const { resolvedTheme } = useTheme()
  const isDark = resolvedTheme === "dark"

  return (
    <div className={`min-h-screen py-24 ${isDark ? "bg-zinc-900 text-white" : "bg-white text-black"}`}>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Hero Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center max-w-3xl mx-auto mb-12 sm:mb-16"
        >
          <h1
            className={`text-3xl sm:text-5xl md:text-6xl font-medium mb-4 sm:mb-6 tracking-tighter ${isDark ? "text-white" : "text-black"}`}
          >
            Build the future of travel. Apply today.
          </h1>
          <p
            className={`text-base sm:text-lg mb-6 sm:mb-8 tracking-tight ${isDark ? "text-gray-400" : "text-gray-600"}`}
          >
            We're building the future of travel technology. Join our team of innovators, dreamers, and doers in
            revolutionizing how the world travels.
          </p>
          <Button
            asChild
            className="bg-emerald-950 text-emerald-300 hover:bg-[#5E6AD2] text-base sm:text-lg px-4 py-3 h-auto"
          >
            <Link href="https://wellfound.com/company/suitpax-1" target="_blank" rel="noopener noreferrer">
              View open positions <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
          </Button>
        </motion.div>

        {/* Benefits Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 md:gap-8 mb-12 sm:mb-16">
          {benefits.map((benefit, index) => (
            <motion.div
              key={benefit.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <Card
                className={`p-5 ${isDark ? "bg-zinc-800/50 border-zinc-700/50 backdrop-blur-sm" : "bg-gray-100 border border-gray-200"}`}
              >
                <div className="flex flex-col items-center justify-center text-center">
                  <benefit.icon className={`w-6 h-6 mb-3 sm:mb-4 ${isDark ? "text-white" : "text-black"}`} />
                  <h3
                    className={`text-xl font-semibold mb-2 sm:mb-3 tracking-tighter ${isDark ? "text-white" : "text-black"}`}
                  >
                    {benefit.title}
                  </h3>
                  <p className={`tracking-tight text-base ${isDark ? "text-gray-400" : "text-gray-600"}`}>
                    {benefit.description}
                  </p>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Job Listings Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.4 }}
        >
          <Card
            className={`p-8 ${isDark ? "bg-zinc-800/50 border-zinc-700/50 backdrop-blur-sm" : "bg-gray-200 border border-gray-200"} max-w-2xl mx-auto`}
          >
            <h2 className={`text-2xl font-bold mb-4 sm:mb-6 tracking-tighter ${isDark ? "text-white" : "text-black"}`}>
              Current Openings
            </h2>
            <p className={`text-gray-400 mb-6 sm:mb-8 tracking-tight ${isDark ? "text-gray-400" : "text-gray-600"}`}>
              We're always looking for talented individuals to join our team. Check out our current openings on
              Wellfound and be a part of our journey in transforming the travel industry.
            </p>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-white/5 rounded-lg">
                <div>
                  <h3 className="font-medium">Engineering</h3>
                  <p className="text-sm text-emerald-700/60">Multiple Positions Available</p>
                </div>
                <ArrowRight className="h-5 w-5 text-emerald-950" />
              </div>
              <div className="flex items-center justify-between p-4 bg-white/5 rounded-lg">
                <div>
                  <h3 className="font-medium">Product & Design</h3>
                  <p className="text-sm text-emerald-700/60">Multiple Positions Available</p>
                </div>
                <ArrowRight className="h-5 w-5 text-emerald-950" />
              </div>
              <div className="flex items-center justify-between p-4 bg-white/5 rounded-lg">
                <div>
                  <h3 className="font-medium">Business Development</h3>
                  <p className="text-sm text-emerald-700/60">Multiple Positions Available</p>
                </div>
                <ArrowRight className="h-5 w-5 text-emerald-950" />
              </div>
            </div>
            <div className="mt-8 text-center">
              <Button asChild variant="secondary" className="border-emerald-500/50 text-black hover:bg-emerald-500/10">
                <Link
                  href="https://wellfound.com/company/suitpax-1"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center"
                >
                  See All Positions on Wellfound
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </div>
          </Card>
        </motion.div>
      </div>
    </div>
  )
}

