import type { MetadataRoute } from "next"

export async function GET(): Promise<Response> {
  const baseUrl = "https://suitpax.com"

  const routes = ["", "/sign-up", "/file-uploader", "/pricing", "/careers"]

  const sitemap: MetadataRoute.Sitemap = routes.map((route) => ({
    url: `${baseUrl}${route}`,
    lastModified: new Date().toISOString().split("T")[0],
    changeFrequency: "daily",
    priority: 0.8,
  }))

  return new Response(JSON.stringify(sitemap), {
    headers: {
      "Content-Type": "application/json",
    },
  })
}

