import { MetadataRoute } from "next"

export async function GET(): Promise<Response> {
  const robotsTxt = `
  # Allow all crawlers
  User-agent: *
  Allow: /

  # Sitemap location
  Sitemap: ${process.env.NEXT_PUBLIC_BASE_URL || "https://suitpax.com"}/sitemap.xml
  `

    return new Response(robotsTxt, {
        headers: {
              "Content-Type": "text/plain",
                  },
                    })
                    }

