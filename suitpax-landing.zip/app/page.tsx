import { Hero } from "@/app/components/hero"
import { PartnersSlider } from "@/app/components/partners-slider" // Import the new component

export default function Home() {
  return (
    <>
      <Hero />
      <PartnersSlider />
    </>
  )
}

