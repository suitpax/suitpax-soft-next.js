"use client"

import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  SiGooglecalendar,
  SiSalesforce,
  SiSlack,
  SiZoom,
  SiGmail,
  SiTripadvisor,
  SiHubspot,
  SiExpedia,
} from "react-icons/si"
import { motion } from "framer-motion"
import { useTheme } from "next-themes"
import { useState } from "react"

const integrations = [
  {
    name: "Google Calendar",
    description: "Sync your travel plans and bookings with your calendar.",
    icon: SiGooglecalendar,
    category: "Productivity",
  },
  {
    name: "Salesforce",
    description: "Export your travel data and expenses for analysis and reporting.",
    icon: SiSalesforce,
    category: "Productivity",
  },
  {
    name: "Slack",
    description: "Collaborate with your team on travel arrangements and updates.",
    icon: SiSlack,
    category: "Communication",
  },
  {
    name: "Zoom",
    description: "Schedule and host virtual meetings for travel planning and coordination.",
    icon: SiZoom,
    category: "Communication",
  },
  {
    name: "Gmail",
    description: "Receive travel confirmations, updates, and important notifications.",
    icon: SiGmail,
    category: "Communication",
  },
  {
    name: "Tripadvisor",
    description: "Access reviews and recommendations for destinations, hotels, and activities.",
    icon: SiTripadvisor,
    category: "Travel Agencies",
  },
  {
    name: "Hubspot",
    description: "Manage customers and accommodations directly through our platform.",
    icon: SiHubspot,
    category: "Hotels",
  },
  {
    name: "Expedia",
    description: "Search and compare flights, hotels, and travel packages.",
    icon: SiExpedia,
    category: "Travel Agencies",
  },
]

const IntegrationCard = ({ name, description, icon: Icon }) => {
  const { resolvedTheme } = useTheme()
  const isDark = resolvedTheme === "light"

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5 }}
      className="p-4 border rounded-lg bg-emerald-950 hover:shadow-md transition-shadow"
    >
      <div className="flex items-center space-x-4">
        <Icon className="w-8 h-8 text-white" />
        <div>
          <h3 className="text-lg font-medium tracking-tighter text-white">{name}</h3>
          <p className="text-sm text-gray-300">{description}</p>
        </div>
      </div>
    </motion.div>
  )
}

export default function IntegrationsPage() {
  const { resolvedTheme } = useTheme()
  const isDark = resolvedTheme === "dark"
  const [selectedCategory, setSelectedCategory] = useState("All")

  const filteredIntegrations =
    selectedCategory === "All"
      ? integrations
      : integrations.filter((integration) => integration.category === selectedCategory)

  return (
    <div className={`min-h-screen py-24 ${isDark ? "bg-zinc-900 text-white" : "bg-white text-black"}`}>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="max-w-3xl mx-auto text-center mb-12 sm:mb-16"
        >
          <h1
            className={`text-2xl sm:text-4xl tracking-tighter font-medium mb-4 ${isDark ? "text-white" : "text-black"}`}
          >
            Integrate your team tools with Suitpax
          </h1>
          <Select onValueChange={(value) => setSelectedCategory(value)} className="max-w-xs mx-auto mb-6">
            <SelectTrigger className="w-full">
              <SelectValue placeholder="Select category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="All">All</SelectItem>
              <SelectItem value="Airlines">Airlines</SelectItem>
              <SelectItem value="Hotels">Hotels</SelectItem>
              <SelectItem value="Travel Agencies">Travel Agencies</SelectItem>
              <SelectItem value="Productivity">Productivity</SelectItem>
              <SelectItem value="Communication">Communication</SelectItem>
            </SelectContent>
          </Select>
          <p
            className={`text-sm py-1
           ${isDark ? "text-gray-400" : "text-gray-600"}`}
          >
            Connect Suitpax with your favorite apps and services to streamline your travel management workflow.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6 md:gap-8">
          {filteredIntegrations.map((integration) => (
            <IntegrationCard key={integration.name} {...integration} />
          ))}
        </div>
      </div>
    </div>
  )
}

