import type { NextConfig } from "next"

const nextConfig: NextConfig = {
  reactStrictMode: true,
  swcMinify: true,
  images: {
    domains: [
      "images.pexels.com",
      "cdn.simpleicons.org"
      "cdn.brandfetch.io",
      "hebbkx1anhila5yf.public.blob.vercel-storage.com",
      "v0.blob.com",
      "uxqxvxvxvxvx.public.blob.vercel-storage.com",
    ],
  },
  experimental: {
    optimizeCss: true,
    optimizePackageImports: ["@heroicons/react", "framer-motion"],
  },
  async headers() {
    return [
      {
        source: "/(.*)",
        headers: [
          {
            key: "X-Frame-Options",
            value: "DENY",
          },
          {
            key: "X-Content-Type-Options",
            value: "nosniff",
          },
          {
            key: "Referrer-Policy",
            value: "strict-origin-when-cross-origin",
          },
        ],
      },
    ]
  },
}

export default nextConfig

