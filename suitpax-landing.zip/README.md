# Suitpax: Next-Gen Travel Management Platform

## Overview

Suitpax is a cutting-edge travel management platform designed to revolutionize the way businesses handle their travel operations. This repository contains the source code for the Suitpax web application, showcasing our AI-powered solutions, global network, and innovative features.

## Table of Contents

- [Tech Stack](#tech-stack)
- [Project Structure](#project-structure)
- [Getting Started](#getting-started)
- [Key Features](#key-features)
- [Development Workflow](#development-workflow)
- [API Integration](#api-integration)
- [Performance Optimization](#performance-optimization)
- [Deployment](#deployment)
- [Contributing](#contributing)
- [License](#license)

## Tech Stack

- **Framework**: Next.js 14 (App Router)
- **Language**: TypeScript
- **Styling**: Tailwind CSS
- **State Management**: Zustand
- **UI Components**: Radix UI, shadcn/ui
- **Animations**: Framer Motion
- **Icons**: Lucide React, Heroicons
- **Form Handling**: React Hook Form
- **Data Fetching**: SWR
- **Authentication**: NextAuth.js
- **API**: RESTful API with Next.js API Routes
- **File Storage**: Vercel Blob Storage
- **Internationalization**: react-intl
- **Testing**: Jest, React Testing Library
- **Linting & Formatting**: ESLint, Prettier
- **Version Control**: Git, GitHub
- **CI/CD**: GitHub Actions, Vercel

## Project Structure

The project follows a modular structure, leveraging Next.js 14 App Router. Key directories include:

- `app/`: Contains pages, layouts, and route handlers
- `components/`: Reusable React components
- `lib/`: Utility functions and shared logic
- `hooks/`: Custom React hooks
- `types/`: TypeScript type definitions
- `public/`: Static assets

For a detailed structure, see [project-structure.txt](./project-structure.txt).

## Getting Started

1. Clone the repository:

